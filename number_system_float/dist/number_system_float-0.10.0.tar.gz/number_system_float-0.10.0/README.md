# NumberSystemFloat
A project for floating-point numbers in the binary, octal, and hexadecimal systems.
